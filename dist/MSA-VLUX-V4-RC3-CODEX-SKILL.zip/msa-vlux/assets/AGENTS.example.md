# Guía opcional de proyecto: MSA-VLUX

Este archivo es un **ejemplo neutro** para copiar manualmente a `AGENTS.md` de un repositorio cuando sea oportuno. No contiene información de proyectos ni permisos preaprobados.

- Cuando el usuario invoque MSA-VLUX, usa la skill `msa-vlux` instalada en `.agents/skills/msa-vlux/` o en tu ruta de skills.
- Antes de trabajar, identifica la realidad del repositorio y comprueba las reglas `AGENTS.md` vigentes; no sobrescribas archivos existentes.
- En proyectos ya existentes sin expediente MSA, usa `AUDIT-0` y produce hallazgos verificables sin alterar código.
- Separa requerimientos aprobados, decisiones de implementación, pruebas, release y despliegue.
- Para cualquier trabajo con efectos externos pide autorización explícita, indicando recurso, acción y alcance exactos.
- Ninguna prueba ejecutada en ambiente desechable autoriza acciones en entornos compartidos o productivos.
- Ningún reporte declara revisión independiente si solamente hubo lentes aplicados por un mismo ejecutor.
