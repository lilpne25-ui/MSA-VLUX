# MSA-VLUX V4.0.0-rc3 — ZIP de skill para Codex

**Contenido genérico.** No incorpora ningún repositorio, aplicación, información de cliente, entorno, historial de conversación o secreto.

## ¿Qué es?

Una *skill* (instrucciones y referencias) de la Metodología Secuencial Atómica. **No instala automáticamente un agente, herramientas, conectores, hooks de seguridad ni permisos.** Portada: `msa-vlux/SKILL.md`. Incluye núcleo y doce módulos.

## Opción A — Subir el ZIP como skill, cuando el producto permita subir skills

Adjunta el archivo ZIP sin modificar. Tiene una sola carpeta raíz `msa-vlux/`, que contiene exactamente un `SKILL.md` con frontmatter. Si el entorno permite cargar skills desde ZIP, úsalo para registrar `msa-vlux`. En Codex sigue siendo necesario que la skill esté instalada/disponible; adjuntar el ZIP como un archivo de conversación no garantiza instalación automática.

## Opción B — Codex local, instalación por proyecto (recomendada para trabajar en un repo)

Extrae el ZIP y copia toda la carpeta `msa-vlux/` a:

```
<RUTA_DEL_REPOSITORIO>/.agents/skills/msa-vlux/
```

Debe existir `<RUTA_DEL_REPOSITORIO>/.agents/skills/msa-vlux/SKILL.md`. Codex podrá descubrirla al trabajar en ese repositorio. Abre una nueva sesión. Pega el texto de `PROMPT-INICIO-CODEX.md`. El archivo `assets/AGENTS.example.md` es opcional: solo úsalo tras revisar y decidir conscientemente modificar el `AGENTS.md` existente del proyecto.

## Opción C — Codex CLI global

Coloca la carpeta `msa-vlux/` en el directorio de habilidades de tu instalación de Codex, normalmente `${CODEX_HOME:-~/.codex}/skills/msa-vlux/`. Si tu versión usa una ruta diferente, compruébala en la configuración actual; no asumas que cualquier ZIP de conversación se instala por sí solo.

## Prueba segura de instalación

Pide: `Usa $msa-vlux. Confirma MSA_VERSION, AGENT_RUNTIME=codex, módulos, límites de seguridad y ejecuta solo un preflight documental sin acceder a ningún repositorio.`

Debe reconocer `4.0.0-rc3`, doce módulos y que `TECHNICAL_GUARDS=not_verified` hasta demostrar controles. No debería elegir un proyecto ni asumir permisos.

## Integridad

`SHA256SUMS.txt` incluye SHA-256 de todos los archivos del paquete excepto el propio manifiesto. Verifica contenido antes de instalar.

## Notas de adaptación

Esta versión usa el núcleo V4.0.0-rc3 y sus doce módulos de la distribución anterior, depurados de referencias a productos, clientes y proyectos específicos y adaptados a Codex. No es una copia binaria de la distribución para otro runtime. No contiene scripts ejecutables ni instala controles de seguridad. Las autorizaciones humanas y la seguridad del sandbox se configuran aparte.
