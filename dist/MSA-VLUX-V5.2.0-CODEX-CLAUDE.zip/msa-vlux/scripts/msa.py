#!/usr/bin/env python3
"""Run from any working directory. python scripts/msa.py doctor"""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from msa_runtime.cli import main
if __name__=='__main__':sys.exit(main())
